import os
import sys

def main():
    epochs = sys.argv[1] if len(sys.argv) > 1 else "150"
    cmd = (
        "nohup /home/imran.imran/Project_Gamma_env/bin/python3 -m torch.distributed.launch "
        "--use_env --nproc_per_node=1 --nnodes=2 --node_rank=0 "
        "--master_addr='10.89.27.239' --master_port=12349 "
        "/home/imran.imran/Project_Gamma/code/train_composition_cvae_dgx.py "
        f"--epochs {epochs} --batch-size 128 --model composition_cvae "
        "> /home/imran.imran/Project_Gamma/code/log_master_composition_cvae.txt 2>&1 &"
    )
    print("Launching composition CVAE master:", cmd)
    os.system(cmd)

if __name__ == "__main__":
    main()