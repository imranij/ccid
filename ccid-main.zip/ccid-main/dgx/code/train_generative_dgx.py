
from __future__ import annotations

import argparse
import os
import time
import json
import gzip
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, Dataset
from torch.utils.data.distributed import DistributedSampler
from sklearn.preprocessing import MinMaxScaler

def is_dist() -> bool:
    return dist.is_available() and dist.is_initialized()

def is_master() -> bool:
    return (not is_dist()) or dist.get_rank() == 0

def setup_distributed(local_rank: int) -> torch.device:
    if "RANK" in os.environ and "WORLD_SIZE" in os.environ:
        dist.init_process_group(backend="nccl")
    if torch.cuda.is_available():
        torch.cuda.set_device(local_rank)
        return torch.device(f"cuda:{local_rank}")
    return torch.device("cpu")

def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path

def load_json_gz(path: Path) -> pd.DataFrame:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        raw = json.load(handle)
    if isinstance(raw, dict) and {"data", "columns", "index"} <= set(raw):
        return pd.DataFrame(raw["data"], columns=raw["columns"], index=raw["index"])
    return pd.DataFrame(raw)

def safe_scaled(series: pd.Series, invert: bool = False) -> np.ndarray:
    values = pd.to_numeric(series, errors="coerce").fillna(0)
    if invert:
        values = -values
    if values.nunique(dropna=True) <= 1:
        return np.full(len(series), 0.5)
    return MinMaxScaler().fit_transform(values.to_numpy().reshape(-1, 1)).reshape(-1)

class PerovskiteDataset(Dataset):
    def __init__(self, data_dir: Path):
        super().__init__()

        shared = data_dir / "shared_datasets" / "matminer"
        castelli_path = shared / "castelli_perovskites.json.gz"
        wolverton_path = shared / "wolverton_oxides.json.gz"
        
        rows = []
        if castelli_path.exists():
            df = load_json_gz(castelli_path)
            out = pd.DataFrame({
                "formula": df["formula"],
                "stability": pd.to_numeric(df.get("e_form", 0), errors="coerce").fillna(0),
                "gap": pd.to_numeric(df.get("gap gllbsc", 0), errors="coerce").fillna(0)
            })
            rows.append(out)
            
        if wolverton_path.exists():
            df = load_json_gz(wolverton_path)
            out = pd.DataFrame({
                "formula": df["formula"],
                "stability": pd.to_numeric(df.get("e_hull", 0), errors="coerce").fillna(0),
                "gap": pd.to_numeric(df.get("gap pbe", 0), errors="coerce").fillna(0)
            })
            rows.append(out)
            
        if not rows:

            print("[Warning] No datasets found, using random fallback data.")
            self.features = torch.randn(1000, 32)
            self.conditions = torch.rand(1000, 2)
            return
            
        df = pd.concat(rows, ignore_index=True)

        c_stab = safe_scaled(df["stability"], invert=True)
        c_gap = safe_scaled(df["gap"])
        self.conditions = torch.tensor(np.column_stack([c_stab, c_gap]), dtype=torch.float32)

        formulas = df["formula"].astype(str).tolist()
        vocab = list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789. ")
        char_to_idx = {ch: i for i, ch in enumerate(vocab)}
        
        bag = np.zeros((len(formulas), len(vocab)))
        for i, f in enumerate(formulas):
            for ch in f:
                if ch in char_to_idx:
                    bag[i, char_to_idx[ch]] += 1

        bag = bag / (bag.sum(axis=1, keepdims=True) + 1e-6)
        
        prop_feat = np.column_stack([
            MinMaxScaler().fit_transform(df["stability"].to_numpy().reshape(-1, 1)),
            MinMaxScaler().fit_transform(df["gap"].to_numpy().reshape(-1, 1))
        ])
        
        feat = np.hstack([bag, prop_feat])
        self.features = torch.tensor(feat, dtype=torch.float32)

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        return self.features[idx], self.conditions[idx]

class ConditionalVAE(nn.Module):
    def __init__(self, input_dim: int, cond_dim: int, latent_dim: int = 16):
        super().__init__()
        self.latent_dim = latent_dim

        self.enc1 = nn.Linear(input_dim + cond_dim, 128)
        self.enc2 = nn.Linear(128, 64)
        self.mu = nn.Linear(64, latent_dim)
        self.logvar = nn.Linear(64, latent_dim)

        self.dec1 = nn.Linear(latent_dim + cond_dim, 64)
        self.dec2 = nn.Linear(64, 128)
        self.out = nn.Linear(128, input_dim)
        
    def encode(self, x, c):
        h = F.relu(self.enc1(torch.cat([x, c], dim=-1)))
        h = F.relu(self.enc2(h))
        return self.mu(h), self.logvar(h)
        
    def decode(self, z, c):
        h = F.relu(self.dec1(torch.cat([z, c], dim=-1)))
        h = F.relu(self.dec2(h))
        return torch.sigmoid(self.out(h))
        
    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std
        
    def forward(self, x, c):
        mu, logvar = self.encode(x, c)
        z = self.reparameterize(mu, logvar)
        return self.decode(z, c), mu, logvar

def vae_loss(recon_x, x, mu, logvar, epoch, max_epochs=100):
    recon_loss = F.mse_loss(recon_x, x, reduction='sum')
    kl_div = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())

    anneal_epochs = min(50, max_epochs // 2)
    beta = min(0.1, 0.1 * (epoch / anneal_epochs))

    free_bits = 0.5 * mu.shape[1]
    kl_loss = torch.clamp(kl_div, min=free_bits)
    
    return recon_loss + beta * kl_loss, recon_loss, kl_div

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model", type=str, default="cvae")
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--local_rank", type=int, default=0)
    p.add_argument("--no_resume", action="store_true")
    return p.parse_args()

def main():
    args = parse_args()
    local_rank = int(os.environ.get("LOCAL_RANK", args.local_rank))
    device = setup_distributed(local_rank)
    
    proj_dir = Path(__file__).resolve().parents[1]
    dataset = PerovskiteDataset(proj_dir.parent)
    
    train_sampler = DistributedSampler(dataset, shuffle=True) if is_dist() else None
    train_loader = DataLoader(dataset, batch_size=args.batch_size, 
                              shuffle=(train_sampler is None),
                              sampler=train_sampler, pin_memory=(device.type == "cuda"))

    input_dim = dataset.features.shape[1]
    cond_dim = dataset.conditions.shape[1]
    
    model = ConditionalVAE(input_dim, cond_dim).to(device)
    if is_dist():
        model = DDP(model, device_ids=[local_rank] if device.type == "cuda" else None,
                    find_unused_parameters=True)
    core = model.module if hasattr(model, "module") else model
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    
    out_dir = ensure_dir(proj_dir / "outputs_dgx")
    ckpt_file = out_dir / f"{args.model}_checkpoint.pt"
    history_path = out_dir / f"{args.model}_history.csv"
    
    start_epoch = 1
    best_loss = float("inf")
    
    if not args.no_resume and ckpt_file.exists():
        loc = f"cuda:{local_rank}" if device.type == "cuda" else "cpu"
        ckpt = torch.load(ckpt_file, map_location=loc, weights_only=False)
        core.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        start_epoch = ckpt["epoch"] + 1
        best_loss = ckpt["best_loss"]
        if is_master():
            print(f"[generative-dgx] resumed from epoch {start_epoch}")

    for epoch in range(start_epoch, args.epochs + 1):
        if train_sampler is not None:
            train_sampler.set_epoch(epoch)
            
        model.train()
        total_loss = 0.0
        total_recon = 0.0
        total_kl = 0.0
        started = time.time()
        
        for x, c in train_loader:
            x, c = x.to(device), c.to(device)
            optimizer.zero_grad(set_to_none=True)
            
            recon_x, mu, logvar = model(x, c)
            loss, recon, kl = vae_loss(recon_x, x, mu, logvar, epoch, args.epochs)
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            total_loss += loss.item()
            total_recon += recon.item()
            total_kl += kl.item()
            
        if is_master():
            avg_loss = total_loss / max(1, len(dataset))
            avg_recon = total_recon / max(1, len(dataset))
            avg_kl = total_kl / max(1, len(dataset))
            
            print(f"[generative-dgx] epoch={epoch} loss={avg_loss:.4f} recon={avg_recon:.4f} kl={avg_kl:.4f}")

            row = f"{epoch},{round(time.time() - started, 2)},{avg_loss},{avg_recon},{avg_kl}\n"
            hdr = "epoch,seconds,loss,recon,kl\n"
            if not history_path.exists():
                with open(history_path, "w") as f:
                    f.write(hdr)
            with open(history_path, "a") as f:
                f.write(row)
                
            if avg_loss < best_loss:
                best_loss = avg_loss
                
            torch.save({"epoch": epoch, "model": core.state_dict(),
                        "optimizer": optimizer.state_dict(),
                        "best_loss": best_loss}, ckpt_file)
                        
        if is_dist():
            dist.barrier()
            
    if is_master():
        print(f"[generative-dgx] complete. best_loss={best_loss:.4f}")
    if is_dist():
        dist.destroy_process_group()

if __name__ == "__main__":
    main()