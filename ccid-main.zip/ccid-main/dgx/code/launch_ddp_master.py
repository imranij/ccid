import os
import sys

def main():
    model = sys.argv[1] if len(sys.argv) > 1 else "cvae"
    cmd = (
        f"nohup /home/imran.imran/Project_Gamma_env/bin/python3 -m torch.distributed.launch "
        f"--use_env --nproc_per_node=1 --nnodes=2 --node_rank=0 "
        f"--master_addr='10.89.27.239' --master_port=12345 "
        f"/home/imran.imran/Project_Gamma/code/train_generative_dgx.py --model {model} "
        f"> /home/imran.imran/Project_Gamma/code/log_master_{model}.txt 2>&1 &"
    )
    print("Launching Master Node:", cmd)
    os.system(cmd)

if __name__ == "__main__":
    main()